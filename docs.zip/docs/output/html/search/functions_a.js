var searchData=
[
  ['toptransportationneedsdistrict_80',['topTransportationNeedsDistrict',['../class_graph.html#a426f2b4364bf611188fc03557e72e04a',1,'Graph']]],
  ['toptransportationneedsmunicipality_81',['topTransportationNeedsMunicipality',['../class_graph.html#a5546e8d97afca3670e976528730052e9',1,'Graph']]]
];
