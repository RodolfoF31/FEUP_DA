var indexSectionsWithContent =
{
  0: "abcdfglmnst",
  1: "fgmns",
  2: "abcdfglmnst"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions"
};

